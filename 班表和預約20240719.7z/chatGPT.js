document.addEventListener('DOMContentLoaded', function() {
    const calendar = document.getElementById('calendar-body');
    const monthYearDisplay = document.getElementById('current-month-year');
    const prevMonthBtn = document.getElementById('prev-month');
    const nextMonthBtn = document.getElementById('next-month');
    const editor = document.getElementById('editor');
    const selectedDateDisplay = document.getElementById('selected-date');
    const addDoctorBtn = document.getElementById('add-doctor');
    const doctorSelection = document.getElementById('doctor-selection');
    const doctorSelect = document.getElementById('doctor-select');
    const confirmDoctorBtn = document.getElementById('confirm-doctor');
    const doctorEditSection = document.getElementById('doctor-edit-section');
    const saveAllBtn = document.getElementById('save-all');
    const clearAllBtn = document.getElementById('clear-all');

    let currentYear, currentMonth;
    let selectedDate;
    let appointments = {};

    function initCalendar() {
        const today = new Date();
        currentYear = today.getFullYear();
        currentMonth = today.getMonth();
        renderCalendar(currentYear, currentMonth);
    }

    function renderCalendar(year, month) {
        calendar.innerHTML = '';
        const firstDay = new Date(year, month, 1).getDay();
        const lastDate = new Date(year, month + 1, 0).getDate();
        const today = new Date();

        monthYearDisplay.textContent = `${year}年 ${month + 1}月`;

        for (let i = 0; i < firstDay; i++) {
            const emptyCell = document.createElement('div');
            emptyCell.className = 'day';
            calendar.appendChild(emptyCell);
        }

        for (let date = 1; date <= lastDate; date++) {
            const day = document.createElement('div');
            day.className = 'day';
            const dateSpan = document.createElement('span');
            dateSpan.className = 'date';
            dateSpan.textContent = date;
            day.appendChild(dateSpan);

            if (year === today.getFullYear() && month === today.getMonth() && date === today.getDate()) {
                day.classList.add('today');
            }

            day.addEventListener('click', function() {
                selectDate(date);
            });

            day.addEventListener('mouseover', function() {
                day.style.backgroundColor = '#e0e0e0';
            });

            day.addEventListener('mouseout', function() {
                day.style.backgroundColor = '';
            });

            calendar.appendChild(day);
        }
    }

    function selectDate(date) {
        selectedDate = `${currentYear}-${currentMonth + 1}-${date}`;
        selectedDateDisplay.textContent = `編輯 ${selectedDate}`;
        editor.style.display = 'block';
        loadAppointments();
    }

    function loadAppointments() {
        doctorEditSection.innerHTML = '';
        const doctors = appointments[selectedDate] || [];
        doctors.forEach(doctor => addDoctorBlock(doctor));
    }

    prevMonthBtn.addEventListener('click', function() {
        if (currentMonth === 0) {
            currentYear--;
            currentMonth = 11;
        } else {
            currentMonth--;
        }
        renderCalendar(currentYear, currentMonth);
    });

    nextMonthBtn.addEventListener('click', function() {
        if (currentMonth === 11) {
            currentYear++;
            currentMonth = 0;
        } else {
            currentMonth++;
        }
        renderCalendar(currentYear, currentMonth);
    });

    addDoctorBtn.addEventListener('click', function() {
        doctorSelection.style.display = 'block';
    });

    confirmDoctorBtn.addEventListener('click', function() {
        const selectedDoctor = doctorSelect.value;
        addDoctorBlock({ name: selectedDoctor, appointments: [] });
        doctorSelection.style.display = 'none';
    });

    function addDoctorBlock(doctor) {
        const doctorBlock = document.createElement('div');
        doctorBlock.className = 'doctor-block';
        doctorBlock.innerHTML = `
            <h3>${doctor.name}</h3>
            <button class="add-appointment">新增預約</button>
            <div class="appointments">
                ${doctor.appointments.map(app => `
                    <div class="appointment">
                        <label>時間:</label>
                        <select class="time-select">
                            ${[...Array(24).keys()].map(hour => `
                                ${[...Array(60).keys()].map(minute => `
                                    <option value="${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}" ${app.time === `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}` ? 'selected' : ''}>
                                        ${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}
                                    </option>
                                `).join('')}
                            `).join('')}
                        </select>
                        <label>客戶:</label>
                        <select class="customer-select">
                            <option value="C1" ${app.customer === 'C1' ? 'selected' : ''}>C1</option>
                            <option value="C2" ${app.customer === 'C2' ? 'selected' : ''}>C2</option>
                            <option value="C3" ${app.customer === 'C3' ? 'selected' : ''}>C3</option>
                        </select>
                        <label>詳細資訊:</label>
                        <textarea class="details">${app.details}</textarea>
                        <button class="save-appointment">保存</button>
                        <button class="delete-appointment">刪除</button>
                    </div>
                `).join('')}
            </div>
        `;
        doctorEditSection.appendChild(doctorBlock);

        const addAppointmentBtn = doctorBlock.querySelector('.add-appointment');
        addAppointmentBtn.addEventListener('click', function() {
            addAppointmentBlock(doctorBlock.querySelector('.appointments'), { time: '', customer: '', details: '' });
        });

        const appointments = doctorBlock.querySelectorAll('.appointment');
        appointments.forEach(appointment => {
            setupAppointmentButtons(appointment, doctor.name);
        });
    }

    function addAppointmentBlock(container, appointment) {
        const appointmentBlock = document.createElement('div');
        appointmentBlock.className = 'appointment';
        appointmentBlock.innerHTML = `
            <label>時間:</label>
            <select class="time-select">
                ${[...Array(24).keys()].map(hour => `
                    ${[...Array(60).keys()].map(minute => `
                        <option value="${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}" ${appointment.time === `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}` ? 'selected' : ''}>
                            ${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}
                        </option>
                    `).join('')}
                `).join('')}
            </select>
            <label>客戶:</label>
            <select class="customer-select">
                <option value="C1" ${appointment.customer === 'C1' ? 'selected' : ''}>C1</option>
                <option value="C2" ${appointment.customer === 'C2' ? 'selected' : ''}>C2</option>
                <option value="C3" ${appointment.customer === 'C3' ? 'selected' : ''}>C3</option>
            </select>
            <label>詳細資訊:</label>
            <textarea class="details">${appointment.details}</textarea>
            <button class="save-appointment">保存</button>
            <button class="delete-appointment">刪除</button>
        `;
        container.appendChild(appointmentBlock);
        setupAppointmentButtons(appointmentBlock, container.parentNode.querySelector('h3').textContent);
    }

    function setupAppointmentButtons(appointment, doctorName) {
        const saveBtn = appointment.querySelector('.save-appointment');
        const deleteBtn = appointment.querySelector('.delete-appointment');
        saveBtn.addEventListener('click', function() {
            const time = appointment.querySelector('.time-select').value;
            const customer = appointment.querySelector('.customer-select').value;
            const details = appointment.querySelector('.details').value;
            saveAppointment(doctorName, { time, customer, details });
        });
        deleteBtn.addEventListener('click', function() {
            appointment.remove();
            deleteAppointment(doctorName, appointment);
        });
    }

    function saveAppointment(doctorName, appointment) {
        if (!appointments[selectedDate]) {
            appointments[selectedDate] = [];
        }
        const doctor = appointments[selectedDate].find(d => d.name === doctorName);
        if (!doctor) {
            appointments[selectedDate].push({ name: doctorName, appointments: [appointment] });
        } else {
            const existingAppointment = doctor.appointments.find(a => a.time === appointment.time && a.customer === appointment.customer);
            if (existingAppointment) {
                existingAppointment.details = appointment.details;
            } else {
                doctor.appointments.push(appointment);
            }
        }
        alert('保存成功');
    }

    function deleteAppointment(doctorName, appointmentElement) {
        const doctor = appointments[selectedDate].find(d => d.name === doctorName);
        if (doctor) {
            const time = appointmentElement.querySelector('.time-select').value;
            const customer = appointmentElement.querySelector('.customer-select').value;
            const appointmentIndex = doctor.appointments.findIndex(a => a.time === time && a.customer === customer);
            if (appointmentIndex !== -1) {
                doctor.appointments.splice(appointmentIndex, 1);
                if (doctor.appointments.length === 0) {
                    appointments[selectedDate] = appointments[selectedDate].filter(d => d.name !== doctorName);
                }
                alert('刪除成功');
            }
        }
    }

    saveAllBtn.addEventListener('click', function() {
        const dateCell = document.querySelector(`.day[date="${selectedDate}"]`);
        const doctorNames = appointments[selectedDate]?.map(d => d.name).join(', ') || '';
        dateCell.querySelector('.appointments-summary').textContent = doctorNames;
        alert('所有資料已保存');
    });

    clearAllBtn.addEventListener('click', function() {
        if (confirm(`是否刪除 ${selectedDate} 的資料？`)) {
            delete appointments[selectedDate];
            loadAppointments();
            const dateCell = document.querySelector(`.day[date="${selectedDate}"]`);
            dateCell.querySelector('.appointments-summary').textContent = '';
            alert('資料已刪除');
        }
    });

    initCalendar();
});
